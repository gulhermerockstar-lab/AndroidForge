@echo off
setlocal
cd /d "%~dp0"
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
set "BT=%ANDROID_HOME%\build-tools\34.0.0"
set "APK=Mesa-Cobrancas-1.0.5-release.apk"
call gradlew.bat :app:assembleRelease || goto erro
"%BT%\zipalign.exe" -f 4 "app\build\outputs\apk\release\app-release-unsigned.apk" "mesa-alinhado.apk" || goto erro
powershell -NoProfile -ExecutionPolicy Bypass -File AUDITAR.ps1 mesa-alinhado.apk || goto erro
set /p "KEY=Caminho da sua chave de release (.jks ou .p12): "
call "%BT%\apksigner.bat" sign --ks "%KEY%" --v1-signing-enabled true --v2-signing-enabled true --out "%APK%" mesa-alinhado.apk || goto erro
call "%BT%\apksigner.bat" verify --min-sdk-version 23 --verbose "%APK%" || goto erro
powershell -NoProfile -ExecutionPolicy Bypass -File AUDITAR.ps1 "%APK%" || goto erro
echo Pronto: %APK%
pause
exit /b 0
:erro
echo Falha: nao envie este build.
pause
exit /b 1
