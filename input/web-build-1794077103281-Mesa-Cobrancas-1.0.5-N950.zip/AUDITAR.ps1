param([Parameter(Mandatory=$true)][string]$Apk)
$ErrorActionPreference='Stop'
$sdk=$env:ANDROID_HOME
if(!$sdk){$sdk=Join-Path $env:LOCALAPPDATA 'Android\Sdk'}
$aapt=Join-Path $sdk 'build-tools\34.0.0\aapt.exe'
$tree=& $aapt dump xmltree $Apk AndroidManifest.xml
if($LASTEXITCODE -ne 0){throw 'Manifesto ilegivel'}
$element=''; $internet=$false
foreach($line in $tree){
 if($line -match '^\s*E: ([^ (]+)'){ $element=$Matches[1] }
 if($element -match '^(uses-permission.*|permission|permission-tree|permission-group)$' -and $line -match 'A: android:name[^=]*="([^"]+)"'){
  $name=$Matches[1]; if($element -ne 'uses-permission' -or $name -ne 'android.permission.INTERNET'){throw "Permissao fora da lista do app: $name ($element)"}; $internet=$true
 }
 if($line -match 'A: android:(debuggable|allowBackup|testOnly|usesCleartextTraffic).*0xffffffff'){throw "Flag nao permitida: $line"}
}
if(!$internet){throw 'INTERNET nao encontrada'}
Write-Host 'OK: somente INTERNET no manifesto.'
