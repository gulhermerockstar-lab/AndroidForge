# Mesa PDV - Point Smart 2 (Produção)

Versão do Mesa-PDV adaptada para Point Smart 2 do Mercado Pago (SmartApps).

**CLIENT_ID de produção já configurado:** `1989579926375306L`

## Versão
- versionName: `2.0.1` (formato válido para a DevConsole)
- versionCode: `201`
- package: `br.com.mesa.cobrancas`

## Como buildar para produção

1. Coloque o AAR do SDK SmartApps em `app/libs/` (fornecido pelo Mercado Pago).
2. Abra o projeto no Android Studio.
3. Gere o APK de **release** (Build > Generate Signed Bundle/APK).
   - Assine com **V1 + V2**.
   - Certifique-se de que **debuggable = false** (já configurado).
4. O APK deve ter menos de 80 MB.
5. Envie em DevConsole > Gerenciamento da SmartApp > Enviar APK.

## Fluxo na DevConsole (conforme manual)

1. Criar aplicação → Pagamentos presenciais → Point SmartApp.
2. Configurar ambiente (terminal debug, SDK, Manifest, metadados, SDK init).
3. Criar caixa e loja.
4. Integrar fluxo de pagamento (meios, parcelas, launchPaymentFlow, status).
5. Testar (aprovado e rejeitado).
6. Enviar APK.
7. Completar informações da SmartApp (título, descrição, categorias, países, logo, imagens, e-mail/site de suporte).
8. Acompanhar: Validação de segurança → Análise interna → Homologação → Distribuição.

## Segurança (para evitar rejeição)
- Apenas permissão INTERNET (já está).
- Bluetooth somente via SDK (já configurado com withBluetoothConfig).
- Release sem debug.
- Activity principal com LAUNCHER + HOME + DEFAULT + MAIN.
- Descrições de pagamento únicas por venda (já implementado).

## WebView
Carrega: `https://mesa-pdv-restaurante.guilnhermedesouzafer.chatgpt.site/mobile-cashier`

Intercepta fluxos antigos de InfinitePay e usa o SDK nativo da Point Smart 2.

Interface JS disponível: `MesaNative.startPayment(amount, description, orderId)`.
