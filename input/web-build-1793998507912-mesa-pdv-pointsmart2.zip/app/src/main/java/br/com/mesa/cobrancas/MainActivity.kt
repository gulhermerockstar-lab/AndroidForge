package br.com.mesa.cobrancas

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mercadolibre.android.point_integration_sdk.nativesdk.MPManager
import com.mercadolibre.android.point_integration_sdk.nativesdk.payment.data.PaymentFlowRequestData
import com.mercadolibre.android.point_integration_sdk.nativesdk.payment.data.PaymentMethod

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private val BASE_URL = "https://mesa-pdv-restaurante.guilnhermedesouzafer.chatgpt.site/mobile-cashier"
    private val APP_VERSION = "2.0.1"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)
        setupWebView()
        webView.loadUrl("$BASE_URL?native_return=mesacashier://result/&app_version=$APP_VERSION")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowContentAccess = true
        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.setSupportZoom(false)
        webView.addJavascriptInterface(MesaNativeInterface(), "MesaNative")
        webView.webChromeClient = object : WebChromeClient() {}
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                return handleUrl(url)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return url?.let { handleUrl(it) } ?: false
            }
        }
    }

    private fun handleUrl(url: String): Boolean {
        val uri = Uri.parse(url)
        if (url.contains("infinitepay.io") || url.contains("infinitepay") ||
            uri.scheme == "mesacashier" || url.contains("order_id") ||
            url.startsWith("mesacashier://")) {
            val orderId = uri.getQueryParameter("order_id") ?: uri.lastPathSegment ?: System.currentTimeMillis().toString()
            val amountStr = uri.getQueryParameter("amount") ?: uri.getQueryParameter("valor") ?: "0.0"
            val description = uri.getQueryParameter("description") ?: uri.getQueryParameter("desc") ?: "Cobrança Mesa PDV #$orderId"
            try {
                val amount = amountStr.replace(",", ".").toDoubleOrNull() ?: 0.0
                if (amount > 0) {
                    startMercadoPagoPayment(amount, description, orderId)
                    return true
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return false
    }

    private fun startMercadoPagoPayment(amount: Double, description: String, orderId: String) {
        try {
            val request = PaymentFlowRequestData(
                amount = amount,
                description = description.take(50),
                paymentMethod = PaymentMethod.POINT,
                printOnTerminal = true
            )
            MPManager.paymentFlow.launchPaymentFlow(request) { result ->
                runOnUiThread {
                    val resultStr = result?.toString() ?: ""
                    val status = if (resultStr.contains("approved", ignoreCase = true) ||
                        resultStr.contains("success", ignoreCase = true) ||
                        resultStr.contains("APPROVED", ignoreCase = true)) "approved" else "rejected"
                    notifyWebPaymentResult(orderId, status, resultStr, amount)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            notifyWebPaymentResult(orderId, "error", e.message ?: "Erro ao iniciar pagamento", amount)
        }
    }

    private fun notifyWebPaymentResult(orderId: String, status: String, reference: String, amount: Double) {
        runOnUiThread {
            val returnUrl = "$BASE_URL?native_return=done&order_id=$orderId&status=$status&reference=$reference&amount=$amount"
            webView.loadUrl(returnUrl)
            Toast.makeText(this, if (status == "approved") "Pagamento aprovado!" else "Pagamento não aprovado", Toast.LENGTH_LONG).show()
        }
    }

    inner class MesaNativeInterface {
        @JavascriptInterface
        fun startPayment(amount: String, description: String, orderId: String) {
            runOnUiThread {
                val amt = amount.replace(",", ".").toDoubleOrNull() ?: return@runOnUiThread
                startMercadoPagoPayment(amt, description, orderId)
            }
        }
        @JavascriptInterface
        fun getVersion(): String = APP_VERSION
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Voltar às cobranças?")
                .setMessage("Uma cobrança aberta não será cancelada.")
                .setPositiveButton("Ficar") { _, _ -> }
                .setNegativeButton("Voltar") { _, _ -> finish() }
                .show()
        }
    }
}
