package br.com.mesa.cobrancas

import android.app.Application
import com.mercadolibre.android.point_integration_sdk.nativesdk.MPManager
import com.mercadolibre.android.point_integration_sdk.nativesdk.configurable.MPConfigBuilder

class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            val config = MPConfigBuilder(this, "1989579926375306")
                .withBluetoothConfig()
                .withBluetoothUIConfig()
                .build()
            MPManager.initialize(this, config)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
