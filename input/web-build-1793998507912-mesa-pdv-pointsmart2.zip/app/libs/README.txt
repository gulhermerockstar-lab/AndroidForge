# Placeholder - coloque o AAR do SDK SmartApps aqui
# Baixe o kit de desenvolvimento com a equipe de integração do Mercado Pago
# Exemplo de nome: nativesdk-mainapp-7.3.1.aar
