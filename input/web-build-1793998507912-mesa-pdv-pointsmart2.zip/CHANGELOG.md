# Changelog - Mesa PDV Point Smart 2

## [2.0.0-pointsmart2] - 2026-11-04

### Adicionado
- Integração completa com SDK SmartApps do Mercado Pago para Point Smart 2
- Substituição do fluxo InfinitePay pelo `launchPaymentFlow` do MP
- Interceptação de URLs/schemes de pagamento antigos
- JavaScript Interface `MesaNative` para iniciar pagamentos a partir da web
- Retorno de status (aprovado/rejeitado) para a WebView
- Exibição da versão na inicialização (requisito de suporte)
- Conformidade com checklist de homologação SmartApps (launcher HOME, CLIENT_ID, minSdk 23, etc.)

### Alterado
- Base do app Mesa-Cobrancas (WebView + rotas originais) adaptada para Point Smart 2
- Package name mantido como `br.com.mesa.cobrancas` (sem referência a MercadoPago)

### Notas
- Requer AAR do SDK fornecido pelo Mercado Pago em `app/libs/`
- CLIENT_ID deve ser configurado no Manifest e Application
