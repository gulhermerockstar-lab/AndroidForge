package br.com.mesa.cobrancas
import org.json.JSONObject
import java.net.URL


import javax.net.ssl.HttpsURLConnection
// Session cookie stays in process memory only. Never follow a redirect with credentials.
internal object MesaApi {
 private const val origin="https://mesa-pdv-restaurante.guilnhermedesouzafer.chatgpt.site"
 @Volatile private var session:String?=null
 fun clear(){session=null}
 fun call(path:String,body:JSONObject?=null):JSONObject {
  require(path=="/api/staff"||path=="/api/smart-cashier")
  val url=URL(origin+path);val c=url.openConnection() as HttpsURLConnection
  try {
   c.instanceFollowRedirects=false;c.connectTimeout=12000;c.readTimeout=25000;c.useCaches=false
   val cookie=session
   if(!cookie.isNullOrEmpty())c.setRequestProperty("Cookie",cookie)
   c.setRequestProperty("Accept","application/json")
   if(body!=null){c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Origin",origin);c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}}
   val code=c.responseCode
   if(code in 300..399)error("Redirecionamento recusado pelo aplicativo.")
   if(path=="/api/staff" && body?.optString("action")=="login" && code in 200..299){
    session=c.headerFields.entries.filter{it.key.equals("Set-Cookie",true)}.flatMap{it.value}.map{it.substringBefore(";").trim()}.firstOrNull{it.matches(Regex("__Host-mesa-session=[a-f0-9]{64}"))}
    if(session==null)error("O PDV aceitou o login, mas a resposta não trouxe o cookie de sessão. Verifique o encaminhamento de Set-Cookie no servidor.")
   }
   val stream=if(code in 200..299)c.inputStream else c.errorStream
   val raw=stream?.bufferedReader(Charsets.UTF_8)?.use{it.readText()}?:""
   val json=runCatching{JSONObject(raw)}.getOrNull()?:error("O servidor não respondeu em JSON.")
   if(code !in 200..299)error(json.optString("error","Falha no servidor: "+code))
   return json
  }finally{c.disconnect()}
 }
}
