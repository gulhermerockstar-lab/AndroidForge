package br.com.mesa.cobrancas
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.mercadolibre.android.point_integration_sdk.nativesdk.MPManager
import com.mercadolibre.android.point_integration_sdk.nativesdk.exception.SDKException
import com.mercadolibre.android.point_integration_sdk.nativesdk.message.utils.doIfError
import com.mercadolibre.android.point_integration_sdk.nativesdk.message.utils.doIfSuccess
import com.mercadolibre.android.point_integration_sdk.nativesdk.payment.data.PaymentRequestData
import com.mercadolibre.android.point_integration_sdk.nativesdk.payment.data.PaymentTransactionMetadata
import com.mercadolibre.android.point_integration_sdk.nativesdk.payment.domain.model.PaymentResponseData
import com.mercadolibre.android.point_integration_sdk.nativesdk.payment.provider.PaymentFlowCallback
import org.json.JSONObject
import java.math.BigDecimal
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
class CashierActivity:AppCompatActivity(){
 private lateinit var panel:LinearLayout
 private val io=Executors.newSingleThreadExecutor();private val handler=Handler(Looper.getMainLooper())
 private fun dp(n:Int)=(resources.displayMetrics.density*n+0.5f).toInt()
 private fun color(s:String)=android.graphics.Color.parseColor(s)
 private var busy=false;private var confirming="";private var generation=0
 private val live get()=!isFinishing&&!isDestroyed
 private fun money(c:Int)=NumberFormat.getCurrencyInstance(Locale("pt","BR")).format(BigDecimal.valueOf(c.toLong(),2))
 private fun box(fill:String,r:Int,line:String=fill)=android.graphics.drawable.GradientDrawable().apply{cornerRadius=dp(r).toFloat();setColor(color(fill));setStroke(dp(1),color(line))}
 private fun row(gap:Int)=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(gap)}
 private fun page(title:String){
  generation++;handler.removeCallbacksAndMessages(null);panel.removeAllViews()
  val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=box("#152421",20);setPadding(dp(18),dp(16),dp(18),dp(20))}
  fun heading(label:String,sp:Int,tint:String){hero.addView(TextView(this).apply{text=label;textSize=sp.toFloat();setTextColor(color(tint));setTypeface(typeface,android.graphics.Typeface.BOLD)})}
  heading("MESA   /   POINT     •     1.0.4",12,"#B7EED2")
  heading(title,28,"#FFFFFF")
  panel.addView(hero,row(14));panel.alpha=0.7f;panel.animate().alpha(1f).setDuration(150).start()
 }
 private fun text(s:String,size:Int=16){panel.addView(TextView(this).apply{text=s;textSize=size.toFloat();setTextColor(color("#223A34"));if(size>=20){background=box("#D9F4DC",14);setTypeface(typeface,android.graphics.Typeface.BOLD)};setPadding(dp(12),dp(10),dp(12),dp(10))},row(4))}
 private fun button(s:String,click:()->Unit){
 val primary=s=="Entrar"||s.startsWith("Cobrar em");val account=s.contains(" · ")
 panel.addView(Button(this).apply{text=s;isAllCaps=false;minHeight=dp(if(account)62 else 50);textSize=17f;setTextColor(color(if(primary)"#FFFFFF" else "#193C33"));if(account)gravity=android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
 setPadding(dp(16),dp(8),dp(16),dp(8));stateListAnimator=null;backgroundTintList=null;background=android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x33888888),box(if(primary)"#126442" else "#FFFFFF",14,if(primary)"#126442" else "#CBD9CF"),null);setOnClickListener{if(!busy)click()}},row(8))}
 private fun field(hint:String,secret:Boolean=false)=EditText(this).also{it.hint=hint;it.isSingleLine=true;it.minHeight=dp(52);it.setTextColor(color("#192F29"));it.setHintTextColor(color("#50645B"));it.background=box("#FFFFFF",12,"#A6BBAE");it.setPadding(dp(14),0,dp(14),0);if(secret)it.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;panel.addView(it,row(10))}
 private fun api(path:String,body:JSONObject?=null,ok:(JSONObject)->Unit){if(busy)return;busy=true;io.execute{val result=runCatching{MesaApi.call(path,body)};runOnUiThread{if(live){busy=false;result.fold(ok){failure->page("Não foi possível concluir");text(failure.message?:"Falha de conexão");button("Consultar contas e pendências"){accounts()};button("Entrar novamente"){login()}}}}}}
 override fun onCreate(saved:Bundle?){super.onCreate(saved);panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(20));setBackgroundColor(color("#F3F8F5"))};setContentView(ScrollView(this).apply{isFillViewport=true;addView(panel)});login()}
 private fun login(){confirming="";page("Acesso ao caixa");text("Entre com sua conta do Mesa PDV.");val u=field("Usuário do caixa");val p=field("Senha",true)
 button("Entrar"){val b=JSONObject().put("action","login").put("username",u.text.toString().trim()).put("password",p.text.toString());p.text.clear();api("/api/staff",b){r->val user=r.getJSONObject("user");if(user.optBoolean("mustChange")||user.optString("role") !in listOf("admin","gerente","caixa")){MesaApi.clear();login();text("Use uma conta de caixa, gerente ou admin com senha já alterada no PDV.")}else if(!(application as MesaApp).initialized){page("Configurar terminal");text("Client ID já configurado. Não foi possível iniciar o SDK do Mercado Pago.");button("Tentar iniciar SDK"){runCatching{(application as MesaApp).configure(BuildConfig.CLIENT_ID)}.onSuccess{accounts()}.onFailure{text("Falha no SDK: "+it.javaClass.simpleName);android.util.Log.e("MesaSDK","Falha ao iniciar SDK",it)}};button("Trocar usuário"){login()}}else accounts()}}}
 private fun accounts(){confirming="";api("/api/smart-cashier"){r->page("Contas do restaurante");val pending=r.getJSONArray("pending");for(i in 0 until pending.length()){val p=pending.getJSONObject(i);button("Consultar pendência · "+money(p.getInt("amount"))){check(p.getString("id"),0)}}
 val a=r.getJSONArray("accounts");if(!r.getBoolean("cashOpen"))text("Caixa fechado");for(i in 0 until a.length()){val g=a.getJSONObject(i);if(!g.getBoolean("locked")&&r.getBoolean("cashOpen"))button(g.getString("name")+" · "+money(g.getInt("amount"))){methods(g,r.getInt("version"))}else text(g.getString("name")+" · indisponível")}
 if(a.length()==0)text("Nenhuma conta aberta.");button("Atualizar"){accounts()};button("Sair"){api("/api/staff",JSONObject().put("action","logout")){MesaApi.clear();login()}}}}
 private fun methods(g:JSONObject,version:Int){page(g.getString("name"));text("Total a receber  "+money(g.getInt("amount")),24);val items=g.getJSONArray("items");for(i in 0 until items.length())text(items.getString(i));button("Voltar"){accounts()};val stamp=generation
 MPManager.paymentMethodsTools.getPaymentMethodsList{reply->reply.doIfSuccess{list->runOnUiThread{if(live&&stamp==generation){val allowed=list.mapNotNull { key->val label=when(key.lowercase(Locale.ROOT)){"credit_card"->"Crédito";"debit_card"->"Débito";"pix","bank_transfer"->"Pix";else->null};label?.let{key to it}};if(allowed.isEmpty())text("Nenhum meio compatível habilitado.");for((key,label) in allowed)button("Cobrar em "+label){reserve(g,version,key,label)}}}}.doIfError{runOnUiThread{if(live&&stamp==generation)text("Não foi possível consultar os meios na Point.")}}}}
 private fun reserve(g:JSONObject,version:Int,key:String,label:String){if(confirming.isNotEmpty())return;val requestId=UUID.randomUUID().toString();api("/api/smart-cashier",JSONObject().put("action","reserve").put("id",requestId).put("ids",g.getJSONArray("ids")).put("method",label).put("version",version)){p->
 val id=p.getString("id");confirming=id;page("Aguardando a maquininha");text("Referência "+id.take(8));val request=PaymentRequestData.builder(BigDecimal.valueOf(p.getLong("amount"),2)).setPaymentMethod(key).setDescription(id).setPrintOnTerminal(true).setPaymentTransactionMetadata(PaymentTransactionMetadata(externalReference=id)).build()
 try{MPManager.paymentFlow.launchPaymentFlow(paymentRequestData=request,callback=object:PaymentFlowCallback{
 override fun onProgress(){};override fun onSuccess(data:PaymentResponseData){val ref=data.paymentReference;if(ref.matches(Regex("[0-9]{1,32}")) && data.externalReference==id && data.paymentStatusError.isNullOrBlank()){getSharedPreferences("receipts",MODE_PRIVATE).edit().putString(id,ref).apply()};runOnUiThread{if(live)check(id,0)}};override fun onError(error:SDKException){runOnUiThread{if(live)check(id,0)}}})}catch(e:Exception){check(id,0)}
 }}
 private fun check(id:String,attempt:Int){confirming=id;api("/api/smart-cashier",JSONObject().put("action","check").put("id",id).put("paymentId",getSharedPreferences("receipts",MODE_PRIVATE).getString(id,null))){p->when(p.getString("status")){
 "approved"->{getSharedPreferences("receipts",MODE_PRIVATE).edit().remove(id).apply();confirming="";page("Pagamento aprovado");text(money(p.getInt("amount"))+" registrado no caixa.");button("Voltar às contas"){accounts()}}
 "cancelled"->{confirming="";page("Pagamento não aprovado");button("Voltar às contas"){accounts()}}
 else->{page("Conferindo pagamento");text("Não cobre de novo. Aguardando confirmação do servidor.");button("Consultar agora"){check(id,0)};button("Voltar às contas"){accounts()};if(attempt<10)handler.postDelayed({if(live&&!busy&&confirming==id)check(id,attempt+1)},4000)}
 }}}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);io.shutdown();super.onDestroy()}
}
