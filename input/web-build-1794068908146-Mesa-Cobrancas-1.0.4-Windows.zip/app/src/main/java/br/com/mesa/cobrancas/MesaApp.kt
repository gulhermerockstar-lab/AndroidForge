package br.com.mesa.cobrancas
import android.app.Application
import com.mercadolibre.android.point_integration_sdk.nativesdk.MPManager
import com.mercadolibre.android.point_integration_sdk.nativesdk.configurable.MPConfigBuilder
class MesaApp:Application(){
 var initialized=false
  private set
 fun configure(id:String){require(id.matches(Regex("[0-9]{1,32}")));if(initialized)return;MPManager.initialize(this,MPConfigBuilder(this,id).build());getSharedPreferences("public_config",MODE_PRIVATE).edit().putString("client_id",id).apply();initialized=true}
 override fun onCreate(){super.onCreate();val id=BuildConfig.CLIENT_ID.ifBlank{getSharedPreferences("public_config",MODE_PRIVATE).getString("client_id","")?:""};runCatching{configure(id)}.onFailure{android.util.Log.e("MesaSDK","Falha ao iniciar SDK",it)}}
}
