@echo off
setlocal
cd /d "%~dp0"
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
call gradlew.bat :app:assembleDebug
if errorlevel 1 goto erro
set "APK=%CD%\Mesa-Cobrancas-1.0.4-teste.apk"
copy /y "app\build\outputs\apk\debug\app-debug.apk" "%APK%" >nul
if errorlevel 1 goto erro
call "%ANDROID_HOME%\build-tools\34.0.0\apksigner.bat" verify --verbose "%APK%"
if errorlevel 1 goto erro
echo APK pronto: "%APK%"
pause
exit /b 0
:erro
echo Falha. Confira a mensagem acima.
pause
exit /b 1
