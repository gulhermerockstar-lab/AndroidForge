# Mesa Cobranças · Point Smart 2
MiniApp Android nativo para cobrar contas do Mesa PDV. Kotlin, Activities/Views Android, API JSON por HTTPS e SDK oficial 7.3.1. Não abre o site, navegador, WebView ou InfinitePay. Não transmite dados por USB. O SDK controla a leitura de cartão, o Pix e o comprovante do terminal. A impressora do caixa continua usando a fila do PDV.
## Primeira configuração
Use a Point de desenvolvimento e o aplicativo/sandbox oficial indicado pelo Mercado Pago. No PDV configure o Access Token da mesma conta recebedora em Integrações → Mercado Pago. Nunca coloque o Access Token, Client Secret nem CSC no APK. Este fluxo nativo não cria uma Order na API de TEF nem requer ativação do modo PDV pela aplicação.
No primeiro acesso entre com um administrador do Mesa PDV e informe o Client ID público da aplicação cadastrada em SmartApps. Também é possível fixá-lo na compilação com -PMESA_CLIENT_ID=SEU_ID_NUMERICO. O Client ID não é um segredo. Cookies e senhas não são gravados no armazenamento permanente. Ao reiniciar o processo, entre novamente. A troca obrigatória da senha inicial é feita no PDV.
## Cobrar
Abra o caixa. Entre como caixa, gerente ou administrador. Escolha uma mesa, balcão ou retirada, confira os produtos e toque na forma oferecida pela Point. O servidor calcula o valor e reserva os pedidos; o SDK recebe a referência gerada pelo servidor. Não há digitação de valor avulso.
O callback inicia uma consulta no servidor, que busca o pagamento por referência e confere seus dados pela Payments API da conta recebedora. Somente aprovação acreditada, referência, valor, moeda e método correspondentes registram a venda. A impressão não fiscal é enfileirada junto com a baixa.
Se a rede cair, o processo for encerrado ou o SDK retornar erro, use Consultar pendência. Não cobre novamente. Sem confirmação do provedor, a reserva permanece bloqueada. Um cancelamento antes da criação de um pagamento pode não produzir registro pesquisável; esse caso exige conciliação de suporte. Não teste a primeira integração em um caixa de atendimento real. Um sandbox de SDK pode não registrar a transação na conta da API; nesse caso o resultado correto do PDV é pendente.
## Compilar e assinar no Windows
Extraia o ZIP. Abra o CMD na pasta em que estão settings.gradle e gradlew.bat. Use JDK 17, Android SDK Platform 34, Build Tools 30.0.3 e 34.0.0, configurados no Android Studio.
    set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
    gradlew.bat clean :app:assembleRelease
O arquivo app/build/outputs/apk/release/app-release-unsigned.apk precisa ser assinado. No Android Studio use Generate Signed Bundle / APK → APK → release, com o keystore da sua empresa. Guarde-o para futuras atualizações. Também pode usar zipalign antes de apksigner, nunca depois. O pacote padrão é br.com.mesa.cobrancas: confirme que é o cadastrado no portal e que a assinatura é compatível com outras versões instaladas.
O ZIP contém o Gradle Wrapper e o AAR real em app/libs; não é necessário recriar o SDK nem copiar imports de outro exemplo.
## Validar antes da homologação
Verifique o manifesto mesclado do release, assinatura (apksigner verify), alinhamento (zipalign -c -v 4), e armazenamento sem compressão de resources.arsc. Na Point de testes valide aprovação, recusa, cancelamento antes do cartão, ausência de rede antes/depois da captura, reinício, troca de usuário, método disponível e impressão. Confira uma única baixa e um único comprovante de caixa. A aprovação formal da versão depende dos testes de segurança e funcionais do Mercado Pago. O app não foi homologado por este desenvolvimento.
## Referências
https://github.com/mercadopago/point-smartapp-demo-android
https://www.mercadopago.com.br/developers/pt/docs/smartapps/restrictions
https://www.mercadopago.com.br/developers/pt/docs/smartapps/integrate-payment-flow
Backend publicado: https://mesa-pdv-restaurante.guilnhermedesouzafer.chatgpt.site — POST /api/staff; GET e POST /api/smart-cashier. O diretório backend contém o patch aplicado sobre a versão 67 (Next/TypeScript + D1); não é um plugin PHP para a VPS fiscal.
